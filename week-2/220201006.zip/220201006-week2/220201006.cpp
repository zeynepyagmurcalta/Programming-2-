


#include <iostream>
using namespace std;

//                        QUESDTION-1

//struct Date {
//    int day;
//    int month;
//    int year;
//};
//
//int main()
//{
//    Date d1;
//    cout << "Please enter the day mounth and year in day/month/year format:" << endl;
//    cin >> d1.day;
//    cin >> d1.month;
//    cin >> d1.year;
//
//    cout << d1.day << "/" << d1.month << "/" << d1.year << endl;
//}


//                        QUESDTION-2

//struct Adress {
//	string city;
//	string street;
//	int housNo;
//
//};
//
//	struct Student {
//		string id;
//		string name;
//		Adress adrs;
//
//	
//};
//
//	int main(){
//		Student s1;
//
//		cout << "please enter the information for the student:"<<endl;
//		cout << "enter the id of student;" << endl;
//		cin >> s1.id;
//		cout << "enter the name of student;" << endl;
//		cin >> s1.name;
//		cout << "enter the city of student;" << endl;
//		cin >> s1.adrs.city;
//		cout << "enter the street of student;" << endl;
//		cin >> s1.adrs.street;
//		cout << "enter the housNo of student;" << endl;
//		cin >> s1.adrs.housNo;
//
//		cout << "Student id:" << s1.id << endl;
//		cout << "Student name:" << s1.name << endl;
//		cout << "Student adress:" << s1.adrs.city << s1.adrs.street << s1.adrs.housNo;
//		
//		
//
//	}


//                        QUESDTION-3
//
//#include <string>
//
//
//struct Student {
//    int id;
//    string name;
//    int marks;
//};
//
//int main() {
//    const int SIZE = 3;
//    Student students[SIZE];
//
//    for (int i = 0; i < SIZE; i++) {
//        cout << "Student " << i + 1 << " ID: ";
//        cin >> students[i].id;
//
//        cout << "Student " << i + 1 << " Name: ";
//        cin >> ws; // Bo�luklar� atlar, getline i�in temizlik yapar
//        getline(cin, students[i].name);
//
//        cout << "Student " << i + 1 << " Marks: ";
//        cin >> students[i].marks;
//    }
//
//    cout << "\n--- Student List ---\n";
//    for (int i = 0; i < SIZE; i++) {
//        cout << students[i].id << " | "
//            << students[i].name << " | "
//            << students[i].marks << endl;
//    }
//
//    return 0;
//}



                        /*QUESDTION-4

int main() {

	int a = 10;

	int *p = &a;
	p = &a;

	cout << "value of x:" << a << endl;
	cout << "address of x :" << p << endl;
	cout << "value trought pointer: "<< *p << endl;


}*/


                        /*QUESDTION-5

int main() {

	int y = 20;

	int* p = &y;

	cout << "before the change y:" << *p << endl;

	*p = *p + 30;

	
	cout << "after the cahnge y" << *p << endl;
}*/



                       /* QUESDTION-6
 
 
void pointer(int *a) {

	*a = *a + 10;

}

int main() {
	int a = 5;

	pointer(&a);

	cout << a << endl;

}*/

//                        QUESDTION-7

//int main() {
//
//	int arr[5] = { 1,2,3,4,5 };
//
//	int* p = arr;
//
//
//	for (int i = 0; i < 5; i++) {
//
//		cout << *(p + i)<<endl;
//	}
//}


//                        QUESDTION-8

//#include <memory>    
//
//
//int main() {
//    unique_ptr<int> ptr = make_unique<int>(42);
//
//    cout << "Value stored in unique_ptr: " << *ptr << endl;
//
//    return 0;
//}
