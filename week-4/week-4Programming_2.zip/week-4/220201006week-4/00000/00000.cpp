// week-4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
#include <string> 



using namespace std;

//                                    TASK-1

/*

int main() {

	string name;

	cout << "please entert the file name for create a file:" << endl;
	cin >> name;

	ofstream file(name +".txt");

	if (file.is_open()) {
		file << "Hello,Word!" << endl;
	}

}*/



//                TASK-2


/*int area(int height,int width ) {

	int answer = height * width;

	ofstream file("rectengle_area.txt");
	file << answer;

	return answer;

}

int main() {

	int width, height;
	cout << "please enter the height and width" << endl;
	cin >> height;
	cin >> width;

	area(width, height);


}*/

//                            TASK-3

/*int main() {

	int arr[5] = { 1,2,3,4,5};
	int square[5];

	for (int i = 0; i < 5; i++) {

		 square[i] = arr[i]*arr[i];

	}

	ofstream file("squares.txt");

	for (int i = 0; i < 5; i++) {
		file << square[i]<<endl;

	}
}*/




//              TASK-4

/*void write_file(string name,string surname) {

	ofstream file("names.log");

	file << name << endl << surname << endl;




}
int main() {

	string name, surname;



	cout << "please enter your name and surname";
	cin >> name;
	cin >> surname;

	write_file(name, surname);


}*/

//                      TASK-5


/*int main() {

	char ch;
	int count = 0;

	ifstream file("sample.txt");

	if (file.is_open()) {

		cout << "Reading the file" << endl;

		while (file.get(ch)) {

			count++;
		}
		file.close();

		cout << "The number of the caracter in the file is:" << count<<endl;

	}



}*/


//                                  TASK-6


/*int main() {

	char ch;

	ifstream file("source.txt");
	ofstream file2("destination.txt");

	if (file.is_open()) {

		while (file.get(ch)){

			file2 << ch;



		}


	}

}*/

//                           TASK-7






/*void findStringInFile(const string& filename, const string& target) {
	ifstream file(filename);
	if (!file) {
		cout << "File not found!\n";
		return;
	}

	string word;
	int count = 0;

	while (file >> word) { 
		if (word == target)
			count++;
	}

	cout << "The string \"" << target << "\" was found " << count << " times.\n";
	file.close();
}

int main() {
	
	findStringInFile("example.txt", "a");
	return 0;
}*/

//             TASK-8



/*int main() {
	ifstream input("numbers.txt");
	ofstream output("average.txt");

	if (!input) {
		cout << "numbers.txt not found!\n";
		return 1;
	}

	double num, sum = 0;
	int count = 0;

	while (input >> num) { 
		sum += num;
		count++;
	}

	if (count > 0)
		output << "Average = " << sum / count;
	else
		output << "No numbers found.";

	cout << "Average written to average.txt\n";

	input.close();
	output.close();
	return 0;
}
*/